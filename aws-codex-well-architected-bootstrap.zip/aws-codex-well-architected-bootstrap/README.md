# {{PROJECT_NAME}}

A lightweight, Codex-native AWS project bootstrap aligned to the AWS Well-Architected Framework.

It keeps the project rigorous without creating a document factory.

## Core model

| Source | Owns |
|---|---|
| `PRD.md` | Requirements, user stories, acceptance criteria, architecture, component design, data flow, error handling, and testing strategy |
| `BUGFIX.md` | Current, expected, and intentionally unchanged behavior for an active defect |
| `TASKS.md` | Executable task graph, dependencies, waves, and live implementation status |
| `AGENTS.md` | How Codex must analyze, plan, implement, validate, and synchronize work |
| `VERIFY.md` | Evidence that requirements and Well-Architected controls are satisfied |
| `RUNBOOK.md` | Repeatable build, deployment, monitoring, rollback, recovery, and teardown procedures |
| `docs/adr/` | Only consequential, difficult-to-reverse architectural decisions |
| GitHub Issues | Durable project-tracking mirror of non-trivial `TASKS.md` items |
| GitHub Projects | Status, priority, wave, release, risk, and evidence views |
| Pull requests | Change review and task-specific implementation evidence |
| Code, tests, schemas, and IaC | Actual system behavior |

## Repository shape

```text
.
├── README.md
├── AGENTS.md
├── PRD.md
├── BUGFIX.md
├── TASKS.md
├── VERIFY.md
├── RUNBOOK.md
├── bootstrap.py
├── app/
│   └── AGENTS.md
├── infrastructure/
│   └── AGENTS.md
├── tests/
│   └── AGENTS.md
├── scripts/
│   └── task_waves.py
├── prompts/
│   └── CODEX-PROMPTS.md
├── docs/
│   └── adr/
│       └── 0000-template.md
└── .github/
    ├── ISSUE_TEMPLATE/
    │   ├── aws-vertical-slice.yml
    │   ├── bugfix.yml
    │   └── waf-risk.yml
    └── PULL_REQUEST_TEMPLATE.md
```

Add nested `AGENTS.md` files only where a directory genuinely needs different rules.

## Project flow

```text
Idea or problem
  -> PRD requirements
  -> requirements analysis gate
  -> PRD technical design
  -> TASKS checklist sorted into dependency-aware waves
  -> execute one task or one safe wave
  -> pull requests and verification evidence
  -> end-of-day GitHub Issue synchronization
  -> deployment and operations through RUNBOOK.md
```

For a defect:

```text
Bug report
  -> BUGFIX.md analysis
  -> regression properties and expected behavior
  -> TASKS.md
  -> implementation and verification
```

## Why design lives in `PRD.md`

For solo builders and small AWS projects, a separate design document often creates another synchronization surface. This template keeps requirements and technical design in one file, but separates them into explicit sections.

Codex must analyze the full requirement set before it may mark the design as ready. The requirements-analysis gate checks for:

- logical inconsistencies;
- ambiguities;
- conflicting constraints;
- unstated assumptions;
- missing edge cases;
- concurrency and failure gaps;
- requirements that cannot be objectively verified.

A separate `DESIGN.md` is appropriate later only if the design has a distinct owner, approval process, audience, or release lifecycle.

## Property-based testing model

The PRD does not contain test code. It defines properties and invariants that implementation tests must prove across generated inputs.

Examples:

- unauthorized actors can never access another tenant's resource;
- duplicate delivery produces one effective result;
- any accepted payload round-trips without data loss;
- retries never exceed the configured bound;
- invalid state transitions never produce a committed state;
- no generated secret or sensitive value appears in telemetry.

Example-based tests still cover known scenarios. Property-based tests explore broader input and state spaces.

## `TASKS.md` and GitHub Issues

`TASKS.md` is the **live execution source** during a Codex work session.

Each non-trivial task receives a stable ID such as `TASK-004`. That ID is copied into its GitHub Issue title or body. By the end of the workday, Codex synchronizes:

- title and outcome;
- acceptance criteria;
- dependencies;
- current status;
- linked pull request;
- validation and evidence summary;
- blockers.

GitHub Issues are the durable collaboration and project-tracking mirror. They do not independently redefine the task.

Tiny implementation steps may remain checkboxes inside a task or issue. Do not create issue spam for every command or variable rename.

## Waves and concurrency

`TASKS.md` declares dependencies. `scripts/task_waves.py` validates them and sorts tasks into waves:

- Wave 1: tasks with no dependencies.
- Wave 2: tasks whose dependencies are all in earlier waves.
- Wave N: continues until every task is assigned.
- A cycle or missing dependency fails validation.

Tasks in one wave are *eligible* for concurrency, not automatically safe to run concurrently. Codex must serialize tasks that:

- edit overlapping files;
- mutate the same AWS resources;
- share mutable state;
- depend on one another semantically;
- require the same irreversible approval gate.

AWS-changing tasks remain approval-gated and should normally run sequentially.

## Task wave commands

```bash
# Show the computed wave plan
python scripts/task_waves.py TASKS.md

# Show tasks whose dependencies are complete
python scripts/task_waves.py TASKS.md --ready

# Show one task
python scripts/task_waves.py TASKS.md --task TASK-001

# Mark a task in progress
python scripts/task_waves.py TASKS.md --set-status TASK-001 IN_PROGRESS

# Link the corresponding GitHub Issue
python scripts/task_waves.py TASKS.md \
  --set-issue TASK-001 https://github.com/OWNER/REPO/issues/12
```

The script validates and updates task metadata. Codex performs the actual implementation.

## Start a new project

Extract this template, then run:

```bash
python bootstrap.py \
  --target ../my-project \
  --project-name "My AWS Project" \
  --region {{AWS_REGION}} \
  --budget {{MONTHLY_BUDGET}}
```

The script skips existing files unless `--force` is supplied.

Then:

```bash
cd ../my-project
git init
git add .
git commit -m "chore: initialize AWS Codex project"
```

## First project actions

0. Confirm the currently available Codex models with `/model`; use the prompt pack's model guide as the workflow default.

1. Complete the workload profile and initial feature requirements in `PRD.md`.
2. Run the requirements-analysis prompt.
3. Resolve or explicitly accept the findings.
4. Complete the architecture and implementation sections in `PRD.md`.
5. Define the MVP or first release outcome.
6. Generate `TASKS.md` as a checklist sorted into dependency-aware waves.
7. Remove irrelevant rows from `VERIFY.md`.
8. Add actual build and deployment procedures to `RUNBOOK.md`.
9. Create a GitHub parent issue for the release.
10. Mirror non-trivial tasks as native GitHub sub-issues.
11. Execute one task or one safe wave at a time.
12. Synchronize task status to GitHub by the end of the workday.

## Suggested GitHub Project fields

| Field | Values |
|---|---|
| Status | Backlog, Ready, In progress, In review, Blocked, Done |
| Priority | Critical, High, Medium, Low |
| Wave | 1, 2, 3, N |
| Primary pillar | Operational Excellence, Security, Reliability, Performance Efficiency, Cost Optimization, Sustainability |
| Risk | High, Medium, Low |
| Release | MVP, v1.0, Hardening, Production |
| Evidence | Not started, Local pass, Pending AWS, Verified |
| Effort | XS, S, M, L |

## Suggested labels

```text
pillar:operational-excellence
pillar:security
pillar:reliability
pillar:performance
pillar:cost
pillar:sustainability

type:feature
type:bug
type:risk
type:operations

status:ready
status:blocked

priority:critical
priority:high
priority:medium
priority:low

evidence:local
evidence:pending-aws
evidence:verified
```

## Prompt pack

[`prompts/CODEX-PROMPTS.md`](prompts/CODEX-PROMPTS.md) begins with a current Codex model-selection guide, then provides reusable prompts for:

1. requirements analysis;
2. completing PRD architecture and design;
3. bugfix analysis;
4. generating the task checklist, waves, and GitHub plan;
5. executing one task;
6. executing a safe wave;
7. end-of-day GitHub synchronization;
8. release-readiness review;
9. post-deployment evidence reconciliation;
10. educational implementation and mentoring mode.


## Educational mode

Use Prompt 10 when you want Codex to implement a real task while explaining:

- the current architecture and affected components;
- relevant AWS services and patterns;
- risks and Well-Architected tradeoffs;
- alternatives considered;
- validation and evidence;
- reusable engineering lessons.

It provides concise milestone updates and a final learning recap without
creating extra tutorial or planning documents.

## Minimality rules

- One fact has one authoritative home.
- Requirements and design live in `PRD.md`.
- Active defect behavior lives in `BUGFIX.md`.
- Executable work and live status live in `TASKS.md`.
- Durable task tracking mirrors to GitHub Issues.
- Proof lives in `VERIFY.md`.
- Operational procedures live in `RUNBOOK.md`.
- Runtime truth lives in code, tests, schemas, IaC, metrics, and logs.
- New Markdown files require a distinct owner and lifecycle.
